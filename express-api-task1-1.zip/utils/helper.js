function makeSongUrl(page=1, query=" ",n=10) {
    return `https://www.jiosaavn.com/api.php?p=${page}&q=${query}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=${n}&__call=search.getResults`
}

function makeAlbumUrl(query=' ',page=1,n=10) {
    return `https://www.jiosaavn.com/api.php?p=${page}&q=${query}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=${n}&__call=search.getAlbumResults`
}

function makeAlbumDetailUrl(albumId) {
//     https://www.jiosaavn.com/api.php?__call=content.getAlbumDetails&albumid={}&api_version=4&_format=json&_marker=0&ctx=web6dot0
    return "https://www.jiosaavn.com/api.php?__call=content.getAlbumDetails&albumid="+albumId+"&api_version=4&_format=json&_marker=0&ctx=web6dot0"
}

function makeSearchPlaylistUrl(query=' ',page=1,n=10) {
    // https://www.jiosaavn.com/api.php?p=1&q={}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=10&__call=search.getPlaylistResults
    return `https://www.jiosaavn.com/api.php?p=${page}&q=${query}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=${n}&__call=search.getPlaylistResults`
}

function makePlayListDetailUrl1(playlistId) {
    // https://www.jiosaavn.com/api.php?__call=playlist.getDetails&listid={}&api_version=4&_format=json&_marker=0&ctx=web6dot0
    return "https://www.jiosaavn.com/api.php?__call=playlist.getDetails&listid="+playlistId+"&api_version=4&_format=json&_marker=0&ctx=web6dot0"
}

function makeTrendingPlaylistUrl() {
    //https://www.jiosaavn.com/api.php?__call=webapi.getLaunchData&api_version=4&_format=json&_marker=0&ctx=web6dot0
    return "https://www.jiosaavn.com/api.php?__call=webapi.getLaunchData&api_version=4&_format=json&_marker=0&ctx=web6dot0"
}

function makeSearchArtistUrl(query=' ',page=1,n=10) {
    // https://www.jiosaavn.com/api.php?p=1&q={}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=10&__call=search.getArtistResults
    return `https://www.jiosaavn.com/api.php?p=${page}&q=${query}&_format=json&_marker=0&api_version=4&ctx=web6dot0&n=${n}&__call=search.getArtistResults`
}

function makeArtistListUrl(artistId, page=1, nSongs=50, nAlbums=50) {
    // https://www.jiosaavn.com/api.php?__call=webapi.get&token={token}&type=artist&p={i}&n_song=50&n_album=50&sub_type=songs&more=true&includeMetaTags=0&ctx=web6dot0&api_version=4&_format=json&_marker=0
    return `https://www.jiosaavn.com/api.php?__call=webapi.get&token=${artistId}&type=artist&p=${page}&n_song=${nSongs}&n_album=${nAlbums}&sub_type=songs&more=true&includeMetaTags=0&ctx=web6dot0&api_version=4&_format=json&_marker=0`
}

function makeAlbumListOfTheYearUrl(language='telugu', year=2023) {
    // https://www.jiosaavn.com/api.php?__call=search.topAlbumsoftheYear&api_version=4&_format=json&_marker=0&ctx=wap6dot0&album_year=2023&album_lang=telugu
    return `https://www.jiosaavn.com/api.php?__call=search.topAlbumsoftheYear&api_version=4&_format=json&_marker=0&ctx=wap6dot0&album_year=${year}&album_lang=${language}`
}


const makeDirectSongUrl = (encryptedMediaUrl) => {
    return `https://www.jiosaavn.com/api.php?__call=song.generateAuthToken&url=${encryptedMediaUrl}&bitrate=320&api_version=4&_format=json&ctx=web6dot0&_marker=0`
}


exports.makeSongUrl = makeSongUrl;
exports.makeAlbumUrl = makeAlbumUrl;
exports.makeAlbumDetailUrl = makeAlbumDetailUrl;
exports.makeSearchPlaylistUrl = makeSearchPlaylistUrl;
exports.makePlayListDetailUrl1 = makePlayListDetailUrl1;
exports.makeTrendingPlaylistUrl = makeTrendingPlaylistUrl;
exports.makeSearchArtistUrl = makeSearchArtistUrl;
exports.makeArtistListUrl = makeArtistListUrl;

// recommended
exports.makeAlbumListOfTheYearUrl = makeAlbumListOfTheYearUrl;



exports.makeDirectSongUrl = makeDirectSongUrl;